# To_do

A simple GUI for [todo.txt](http://todotxt.org/) files

## License

[MIT](https://choosealicense.com/licenses/mit/)
