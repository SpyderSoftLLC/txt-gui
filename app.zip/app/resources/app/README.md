# To_do

A simple GUI for [todo.txt](http://todotxt.org/) files

# Instructions
1. Download the app.zip file
2. Extract files to desired location
3. Run to_do.exe 

## License

[MIT](https://choosealicense.com/licenses/mit/)
